from flask import Flask, render_template, request

app = Flask(__name__)




listado_productos = [
    dict(
        name=dict(
            first='Parlante',
        ),
        ),

    dict(
        name=dict(
            first='cargador'
        ),
        ),
]


@app.route('/') # app es la instancia, route el metodo, '/' es el disparador
def index():
    return render_template(
        'index.html',
    )


@app.route('/productos')
def productos():
    listado = listado_productos    
    return render_template(
        'productos.html',
        listado = listado
        )

@app.route('/add_productos', methods=['GET', 'POST'])
def add_productos(): 
    if request.method == 'POST':
                    
        first_name = request.form['nombre'] 
        producto = dict(
            name=dict(
                first=first_name
            )
        )
        listado_productos.append(producto)
    return render_template('add_productos.html')







